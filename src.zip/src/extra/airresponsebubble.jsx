import React from "react";
import { motion } from "framer-motion";

const AIResponseBubble = ({ content }) => (
  <motion.div
    className="ai-bubble"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.4, ease: [0.25, 1, 0.5, 1] }}
  >
    <div className="bubble-inner">{content}</div>
  </motion.div>
);

export default AIResponseBubble;
