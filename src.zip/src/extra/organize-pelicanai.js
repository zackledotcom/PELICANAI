// Run: node organize-pelicanai.js in your flat directory
const fs = require("fs");
const path = require("path");

const MOVE_MAP = [
  { dir: "src", files: ["App.jsx", "AppLayout.jsx", "style.css"] },
  { dir: "src/components", files: ["MessageBubble.jsx", "AIResponseBubble.jsx", "SlideoutControls.jsx", "MemoryInspector.jsx"] },
  { dir: "src/providers", files: ["ThemeProvider.jsx"] },
  { dir: "src/hooks", files: ["useVectorMemory.js", "useTokenBudget.js", "useEmotionAwareTheme.js", "useColdStartRecovery.js", "useMemoryInjection.js"] },
  { dir: "src/utils", files: ["classnames.js", "perf.js"] }
];

// Utility: create directory if missing
function mkdirpSync(dirPath) {
  if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
}

MOVE_MAP.forEach(({ dir, files }) => {
  mkdirpSync(dir);
  files.forEach((f) => {
    const src = path.join(".", f);
    const dest = path.join(dir, f);
    if (fs.existsSync(src)) {
      if (!fs.existsSync(dest)) {
        fs.renameSync(src, dest);
        console.log(`Moved ${f} → ${dest}`);
      } else {
        console.warn(`Skipped ${f}: already exists in ${dir}`);
      }
    }
  });
});

// Move style.css to src if present
if (fs.existsSync("style.css")) {
  mkdirpSync("src");
  fs.renameSync("style.css", "src/style.css");
}

console.log("Done. Project structure:");
function printDir(dir, indent = 0) {
  fs.readdirSync(dir).forEach(f => {
    const p = path.join(dir, f);
    const prefix = " ".repeat(indent * 2);
    if (fs.statSync(p).isDirectory()) {
      console.log(`${prefix}${f}/`);
      printDir(p, indent + 1);
    } else {
      console.log(`${prefix}${f}`);
    }
  });
}
printDir("src");
