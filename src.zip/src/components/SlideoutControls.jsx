import React, { useState } from "react";
import "./styles/layout.css";

export default function SlideoutControls() {
  const [open, setOpen] = useState(false);

  return (
    <aside className={`slideout-controls ${open ? "open" : ""}`}>
      <button
        className="slideout-toggle"
        aria-label={open ? "Close controls" : "Open controls"}
        onClick={() => setOpen((v) => !v)}
      >
        {open ? "Close" : "Controls"}
      </button>
      {open && (
        <div className="slideout-content">
          {/* Add custom controls, toggles, or settings here */}
        </div>
      )}
    </aside>
  );
}
