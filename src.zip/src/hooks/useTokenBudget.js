import { useState } from "react";

const useTokenBudget = (limit = 6000) => {
  const [used, setUsed] = useState(0);
  const [budget] = useState(limit);

  const consume = (tokens) => setUsed((u) => u + tokens);
  const reset = () => setUsed(0);

  return { used, budget, remaining: budget - used, consume, reset };
};

export default useTokenBudget;
