import { useEffect } from "react";
import useVectorMemory from "./useVectorMemory";
import useTokenBudget from "./useTokenBudget";

const useMemoryInjection = (messages) => {
  const { memories } = useVectorMemory();
  const { budget, consume } = useTokenBudget();

  useEffect(() => {
    // Token-budgeted, context-aware injection
    let tokensUsed = 0;
    memories.forEach((mem) => {
      if (tokensUsed + mem.tokenCount < budget) {
        // inject this memory
        tokensUsed += mem.tokenCount;
        consume(mem.tokenCount);
      }
    });
  }, [messages, memories, budget, consume]);
};

export default useMemoryInjection;
