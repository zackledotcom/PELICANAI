import { useState, useCallback } from "react";
import { getEmbeddings, queryQdrant, pinQdrant, unpinQdrant } from "./vectorAPI";

const useVectorMemory = () => {
  const [memories, setMemories] = useState([]);
  const [pinned, setPinned] = useState(new Set());

  const refresh = useCallback(async () => {
    const data = await queryQdrant();
    setMemories(data);
  }, []);

  const pinMemory = useCallback(
    (id) => {
      pinQdrant(id);
      setPinned((pins) => new Set(pins).add(id));
    },
    [setPinned]
  );

  const unpinMemory = useCallback(
    (id) => {
      unpinQdrant(id);
      setPinned((pins) => {
        const next = new Set(pins);
        next.delete(id);
        return next;
      });
    },
    [setPinned]
  );

  const isPinned = useCallback((id) => pinned.has(id), [pinned]);

  return { memories, pinMemory, unpinMemory, isPinned, refresh };
};

export default useVectorMemory;
