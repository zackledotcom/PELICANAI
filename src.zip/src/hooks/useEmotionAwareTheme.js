import { useContext } from "react";
import { ThemeContext } from "./ThemeProvider";

const useEmotionAwareTheme = (messages) => {
  const { theme } = useContext(ThemeContext);
  if (!messages || messages.length === 0) return theme;
  const last = messages[messages.length - 1].content || "";
  if (/error|sad|fail/i.test(last)) return "dark";
  if (/success|happy|win/i.test(last)) return "light";
  return theme;
};

export default useEmotionAwareTheme;
